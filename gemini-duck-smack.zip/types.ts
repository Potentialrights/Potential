
export enum GameState {
  READY,
  PLAYING,
  GAME_OVER,
}
