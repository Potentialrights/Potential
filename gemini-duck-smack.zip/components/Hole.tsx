import React from 'react';
import Duck from './Mole'; // The file is still called Mole.tsx, but exports Duck

interface HoleProps {
  isDuckUp: boolean;
  onWhack: () => void;
}

const Hole: React.FC<HoleProps> = ({ isDuckUp, onWhack }) => {
  return (
    <div className="relative w-24 h-24 md:w-32 md:h-32 flex items-center justify-center">
      {/* Grass mound */}
      <div className="absolute w-full h-full bg-green-600/70 rounded-full"></div>
      <div className="absolute w-full h-full scale-95 bg-green-700/80 rounded-full"></div>
      
      {/* The hole itself */}
      <div className="relative w-20 h-20 md:w-24 md:h-24 bg-[#3D2B1F] rounded-full overflow-hidden shadow-inner">
         <div className="absolute inset-0 bg-black/40 rounded-full"></div>
         <Duck isUp={isDuckUp} onClick={onWhack} />
      </div>
    </div>
  );
};

export default Hole;