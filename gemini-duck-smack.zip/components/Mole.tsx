import React from 'react';

interface DuckProps {
  isUp: boolean;
  onClick: () => void;
}

const DuckIcon: React.FC = () => (
    <svg viewBox="0 0 100 80" className="w-full h-full">
        {/* Head */}
        <path d="M 15,80 C 5,50 30,10 50,10 C 70,10 95,50 85,80 Z" fill="#FFD700" />
        {/* Beak */}
        <path d="M 35,65 C 20,75 80,75 65,65 Q 50,60 35,65 Z" fill="#FFA500" />
        {/* Eyes */}
        <circle cx="38" cy="40" r="5" fill="black" />
        <circle cx="62" cy="40" r="5" fill="black" />
        {/* Eye gleam */}
        <circle cx="40" cy="38" r="1.5" fill="white" />
        <circle cx="64" cy="38" r="1.5" fill="white" />
        {/* Tuft */}
        <path d="M 45,10 Q 50,0 55,10 T 60 12" fill="#FFD700" stroke="#F0C400" strokeWidth="2" />
    </svg>
);


const Duck: React.FC<DuckProps> = ({ isUp, onClick }) => {
  return (
    <div
      className={`absolute bottom-4 w-20 h-16 cursor-pointer will-change-transform transition-transform duration-150 ease-out origin-bottom ${
        isUp ? 'translate-y-0' : 'translate-y-full'
      }`}
      onClick={isUp ? onClick : undefined}
      onMouseDown={(e) => e.preventDefault()}
    >
      <DuckIcon />
    </div>
  );
};

export default Duck;