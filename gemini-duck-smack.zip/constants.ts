
export const GAME_DURATION = 30; // seconds
export const MOLE_UP_MIN_TIME = 400; // milliseconds
export const MOLE_UP_MAX_TIME = 1000; // milliseconds
export const GRID_SIZE = 9;
